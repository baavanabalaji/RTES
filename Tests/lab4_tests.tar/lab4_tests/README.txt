Usage:

In order to run the tests on your applications and modules, place the
following user scripts & built modules in the same directory as lab4.sh.

In order to run the TA binaries, leave them in the tools directory (created in the same directory as lab4.sh) as in this package. Build the TA rsvmgr application using the Makefile in the tools directory, after pointing the EXP_HDRS variable to the correct location of your usr/include folder. Please run only the tests that are printed on the tablet when you execute "sh lab4.sh help"
