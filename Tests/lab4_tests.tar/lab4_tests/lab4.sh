#!/sbin/bash
TOOLS_DIR=tools

CPUS="0 1 2 3"
FREQS="340000 640000 1000000 1200000"
MAX_FREQ=1300000

UTILS="0.25 0.5 0.75 1.0"
ENERGY_TEST_UTILS="0.25 0.5 0.75 0.9 1.0"


RTES_DIR=/sys/rtes
FREQ_FILE=$RTES_DIR/freq
PWR_FILE=$RTES_DIR/power

CPU_DIR=/sys/devices/system/cpu

do_check()
{
    local CHECK_FUNC=$1
    local DESC="$2"
    $CHECK_FUNC
    if [ "$?" -ne 0 ]
    then
        echo "Test '$CHECK_FUNC $DESC' failed"
        exit 1
    fi
}

# Parses: "0,4-7" into "0 4 5 6 7"
cpu_set_to_list()
{
    local CPU_SET=$1

    local CPU_SET_STR="$(echo $CPU_SET | sed 's/,/ /g')"
    for range in $CPU_SET_STR
    do
        if echo $range | grep -q '-'
        then
            echo -n "$range " | sed 's/-/ /g' | xargs -n 2 seq
        else
            echo -n "$range "
        fi
    done
    echo
}

list_len()
{
    local LIST="$@"
    local LEN=0
    for e in $LIST
    do
        local LEN=$(($LEN + 1))
    done
    echo $LEN
}

set_cpu_param()
{
    local SETTING=$1
    local VALUE=$2
    if [ "$#" -gt 2 ]
    then
        shift 2
        local CPUS="$@"
    else
        local CPUS="0 1 2 3"
    fi

    if [ $SETTING != "online" ]
    then
        local SETTING="cpufreq/$SETTING"
    fi

    for i in $CPUS
    do
        local FILE=$CPU_DIR/cpu$i/$SETTING
        if [ -e $FILE ]
        then
            echo $VALUE > $FILE
        fi
    done
}

set_freq()
{
    local FREQ=$1
    set_cpu_param scaling_setspeed $FREQ
    sleep 0.5
}

set_gov()
{
    local GOV=$1
    set_cpu_param scaling_governor $GOV
    sleep 0.5
}

check_value()
{
    local VAL=$1
    local REF=$2
    local DESC="$3"
    local TOLERANCE=0.10 # fraction: error/ref
    local CMP=$($TOOLS_DIR/fcalc $REF $VAL - a $REF s '/' $TOLERANCE '<')
    if [ "$CMP" -ne 0 ]
    then
        echo "FAILED: value not within tolerance (+-$($TOOLS_DIR/fcalc $TOLERANCE 100 '*')%): " \
            "value $VAL ref $REF"
        return 1
    else
        echo "value $VAL ref $REF (<+-$($TOOLS_DIR/fcalc $TOLERANCE 100 '*')%)"
    fi
    return 0
}

check_file()
{
    local FILE=$1
    if ! [ -e $RTES_DIR/$FILE ]
    then
        echo "FAILED: $FILE file not found"
        return 1
    fi
    return 0
}

launch_busyloop()
{
    local C=$1
    local T=$2
    local CPU=$3

    #chrt -f 50 $TOOLS_DIR/busyloop &
    $TOOLS_DIR/busyloop &
    BUSY_PID=$!
    sleep 0.5

    # 100% reserve: we want it to always be running
    ./tools/rsvmgr set $BUSY_PID $C $T $CPU

    chrt -f -p 50 $BUSY_PID &> /dev/null
}

launch_busyloop_util()
{
    local U=$1
    local CPU=$2

    local T=500
    local C=$($TOOLS_DIR/fcalc $U $T '*')

    launch_busyloop $C $T $CPU
}

launch_busyloops()
{
    local UTIL=$1
    shift
    local CPUS="$@"
    BUSY_PIDS=""
    for cpu in $CPUS
    do
        launch_busyloop_util $UTIL $cpu
        BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    done
}

kill_busyloops()
{
    #for pid in $BUSY_PIDS
    #do
    #    ./tools/rsvmgr cancel $pid
    #done
    kill -9 $BUSY_PIDS
    #killall busyloop
}

test_freq_tracking()
{
    local TEST_RESULT=0

    launch_busyloops 1.0 0

    for freq in $FREQS
    do
        set_freq $freq
        if ! check_file freq
        then
            TEST_RESULT=1
            break
        fi
        local REF_FREQ=$((freq / 1000))
        if ! grep "^[ \\t]*$REF_FREQ" $FREQ_FILE
        then
            local FREQ="$(head -1 $FREQ_FILE)"
            echo "FAILED: freq ($FREQ) does not match expected freq ($REF_FREQ)"
            TEST_RESULT=1
            break
        fi
    done

    kill_busyloops
    return $TEST_RESULT
}

calc_pwr()
{
    local FREQ=$1
    local NUM_CPUS=$2
    local KAPPA="0.00442"
    local ALPHA="1.67"
    local BETA="25.72"
    echo $($TOOLS_DIR/fcalc \
        1000 $FREQ '/' $ALPHA s p $KAPPA '*' $BETA '+' $NUM_CPUS '*')
}

check_pwr()
{
    local FREQ=$1
    local NUM_CPUS=$2
    check_value $(cat $PWR_FILE) $(calc_pwr $FREQ $NUM_CPUS) "power"
}

check_pwr_freqs()
{
    local NUM_CPUS=$1
    shift
    local FREQS="$@"
    local TEST_RESULT=0

    if ! check_file power
    then
        return 1 
    fi

    launch_busyloops 1.0 $(seq 0 $(($NUM_CPUS - 1)))

    for freq in $FREQS
    do
        echo "Check power consumption of $NUM_CPUS CPU(s) with freq $freq"
        set_freq $freq 
        if ! check_pwr $freq $NUM_CPUS
        then
            TEST_RESULT=1
            break
        fi
    done

    kill_busyloops
    return $TEST_RESULT
}

check_pwr_cpus()
{
    local FREQS="$@"
    for num_cpus in 2 3 4
    do
        if ! check_pwr_freqs $num_cpus $FREQS
        then
            return 1
        fi
    done
    return 0
}

test_pwr_one_freq_one_cpu()
{
    check_pwr_freqs 1 $MAX_FREQ
}

test_pwr_one_cpu_many_freqs()
{
    check_pwr_freqs 1 $FREQS
}

test_pwr_many_cpus()
{
    check_pwr_cpus $MAX_FREQ
}

test_pwr_many_cpus_many_freqs()
{
    check_pwr_cpus $FREQS
}

check_energy_freqs()
{
    local FREQS="$1"
    local UTILS="$2"

    for freq in $FREQS
    do
        set_freq $freq

        for util in $UTILS
        do
            local REF_PWR=$(calc_pwr $freq 1)
            local REF_ENERGY=$($TOOLS_DIR/fcalc $REF_PWR 10 '*' $util '*')
            echo 0 > $RTES_DIR/energy

            launch_busyloops $util 0
            sleep 10
            local PID=$(echo $BUSY_PIDS) # trim whitespace
            local ENERGY=$(cat $RTES_DIR/tasks/$PID/energy)
	    local TOTAL_ENERGY=$(cat $RTES_DIR/energy)
            kill_busyloops

	    echo Task util: $util, CPU freq: $freq 
            check_value $ENERGY $REF_ENERGY "energy"
            #check_value $TOTAL_ENERGY $REF_ENERGY "energy"
        done
    done
}

test_energy_one_freq_one_u()
{
    check_energy_freqs "$MAX_FREQ" "0.9"
}

test_energy_one_freq_one_u_max()
{
    check_energy_freqs "$MAX_FREQ" "1.0"
}

test_energy_many_freqs_one_u()
{
    check_energy_freqs "$FREQS" "0.9"
}

test_energy_many_freqs_one_u_max()
{
    check_energy_freqs "$FREQS" "1.0"
}

test_energy_max_freq_many_u()
{
    check_energy_freqs "$MAX_FREQ" "$UTILS"
}

test_energy_many_freqs_many_u()
{
    check_energy_freqs "$FREQS" "$UTILS"
}

reset_energy()
{
    echo 0 > $RTES_DIR/energy
}

check_energy_sum()
{
    local UTIL=$1
    shift
    local CPUS="$@"

    reset_energy

    local ENERGIES=""

    launch_busyloops $UTIL $CPUS
    sleep 10
    for pid in $BUSY_PIDS
    do
        local ENERGY=$(cat $RTES_DIR/tasks/$pid/energy)
        local ENERGIES="$ENERGIES $ENERGY"
    done
    kill_busyloops

    local TOTAL_E=0
    for e in $ENERGIES
    do
        local TOTAL_E=$($TOOLS_DIR/fcalc $TOTAL_E $e '+')
    done

    echo Per-task util: $UTIL, CPU list: $CPUS
    check_value $TOTAL_E $(cat $RTES_DIR/energy) "total energy"
}

test_energy_sum_two_same_cpu()
{
    check_energy_sum 0.25 0 0
}

test_energy_sum_three_same_cpu()
{
    check_energy_sum 0.25 0 0 0
}

test_energy_sum_two_diff_cpu()
{
    check_energy_sum 0.25 0 1
}

test_energy_sum_many()
{
    check_energy_sum 0.25 0 0 1 1 2 2 3 3
}

test_energymon_heavy()
{
    # MANUAL TEST: view the energymon (native and Android) output and check
    # that energy grows faster
    reset_energy
    set_freq $MAX_FREQ
    launch_busyloops 0.5 0
    sleep 0.5
    ./energymon $BUSY_PIDS
    kill_busyloops
}

test_energymon_light()
{
    # MANUAL TEST: view the energymon (native and Android) output and check that
    # energy grows slower
    reset_energy
    set_freq 640000 
    launch_busyloops 0.25 0
    sleep 0.5
    ./energymon $BUSY_PIDS
    kill_busyloops
}

test_energymon_heavy2()
{
    # MANUAL TEST: view the energymon (native and Android) output and check
    # that energy grows same as in heavy test
    reset_energy
    set_freq $MAX_FREQ
    launch_busyloops 0.25 0 0
    sleep 0.5
    ./energymon 0
    kill_busyloops
}

cycle_freqs()
{
    for freq in $FREQS
    do
        sleep 5
        set_freq $freq
    done
}

test_energymon_freqs_android_app()
{
    # MANUAL TEST: view energymon (native and Android) output and check that the
    # frequency changes
    reset_energy
    launch_busyloops 0.25 0
    cycle_freqs &
    ./energymon 0
}

add_tasks()
{
    NUM_TASKS=3 # one per CPU
    for i in $(seq $NUM_TASKS)
    do
        sleep 5
        launch_busyloops 0.25 $i
    done
    kill_busyloops
}

test_energymon_tasks()
{
    # MANUAL TEST: view energymon (native and Android) output and check that
    # energy grows progressively faster (as new tasks are added)
    reset_energy
    launch_busyloops 0.25 0
    add_tasks &
    ./energymon 0
    kill_busyloops
}


check_online_count()
{
    local REF_COUNT=$1

    local ONLINE=$(cat $CPU_DIR/online)
    local ONLINE_LIST=$(cpu_set_to_list $ONLINE)
    local ONLINE_COUNT=$(list_len $ONLINE_LIST)

    if [ "$ONLINE_COUNT" -ne "$REF_COUNT" ]
    then
        echo "FAILED: online processors ($ONLINE) " \
            "do not match expected ($REF_COUNT)"
        return 1
    fi
    return 0
}

check_unused()
{
    local UTIL=$1
    local CPUS="$2"
    local REF_COUNT="$3"

    local TEST_RESULT=0
    launch_busyloops $UTIL $CPUS
    sleep 2
    if ! check_online_count $REF_COUNT
    then
        TEST_RESULT=1
    fi
    kill_busyloops
    return $TEST_RESULT
}

test_unused_static()
{
    check_unused 0.25 0 1
}

test_unused_partition()
{
    check_unused 0.75 "-1 -1 -1" 3
}

test_unused_partition_wfd()
{
    echo WFD > $RTES_DIR/partition_policy
    check_unused 0.25 "-1 -1 -1" 1
}

test_unused_partition_lst()
{
    echo LST > $RTES_DIR/partition_policy
    check_unused 0.25 "-1 -1 -1" 3
}

test_partition_lst()
{
    local TEST_RESULT=0
    echo LST > $RTES_DIR/partition_policy
    launch_busyloops 0.25 -1 -1 -1 -1 -1 -1 -1 -1
    local REF_COUNT=2
    cp $RTES_DIR/reserves reserves.$$
    for core in 0 1 2 3
    do
        local COUNT=$(grep -cE "[^0-9]+$core[^0-9]+" $RTES_DIR/reserves)
        if [ "$COUNT" -ne $REF_COUNT ]
        then
            echo "FAILED: task count on core $core ($COUNT) " \
                "does not match expected ($REF_COUNT)"
            TEST_RESULT=1
            break
        fi
    done
    kill_busyloops
    return $TEST_RESULT
}

check_freq()
{
    local FREQ=$1
    local REF_FREQ=$2
    #if [[ ("$FREQ" -eq "$REF_FREQ") || ("$FREQ" -eq "1300" && "$REF_FREQ" -eq "1200") ]]
    if [[ "$FREQ" -eq "$REF_FREQ" ]] 
    then
        echo "freq ($FREQ) matches expected ($REF_FREQ)"
	    return 0	
    fi
    if [[ "$FREQ" -eq "1300" && "$REF_FREQ" -eq "1200" ]]
    then
        echo "freq ($FREQ) matches expected ($REF_FREQ)"
	    return 0	
    fi
    echo "FAILED: freq ($FREQ) does not match expected ($REF_FREQ)"
    return 1
}

test_sysclock_min()
{
    set_gov sysclock
    local BUSY_PIDS=""
    launch_busyloop 200 1000 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    echo "Tasks (C, T): (200, 1000)"

    local REF_FREQ=340 # 1200*0.20=240
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_sysclock_max()
{
    set_gov sysclock
    local BUSY_PIDS=""
    launch_busyloop 475 500 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    echo "Tasks (C, T): (475, 500)"

    local REF_FREQ=1200 # 1200*0.95=1140
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_sysclock_one_cpu_1()
{
    set_gov sysclock
    local BUSY_PIDS=""
    launch_busyloop 300 1000 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 200 2000 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 250 4000 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"

    echo "Tasks (C, T): (300, 1000), (200, 2000), (250, 4000)"

    local REF_FREQ=640 # 1200*0.4625=555
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_sysclock_one_cpu_2()
{
    set_gov sysclock
    local BUSY_PIDS=""
    launch_busyloop 200 600 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 150 700 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 100 800 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"

    echo "Tasks (C, T): (200, 600), (150, 700), (100, 800)"

    local REF_FREQ=1000 # 1200000*0.75=900000
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_sysclock_one_cpu_3()
{
    set_gov sysclock
    local BUSY_PIDS=""
    launch_busyloop 200 1375 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 800 1600 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 250 7000 0
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"

    echo "Tasks (C, T): (200, 1375), (800, 1600), (250, 7000)"

    local REF_FREQ=1000 # 1200*0.7273=873
    # But if task 3's limit is considered then 1200*0.6953=834 => 760
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_sysclock_two_cpu_lst()
{
    set_gov sysclock
    echo LST > $RTES_DIR/partition_policy

    local BUSY_PIDS=""
    launch_busyloop 300 1000 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 200 2000 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 250 4000 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"

    launch_busyloop 200 600 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 150 700 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    launch_busyloop 100 800 -1
    local BUSY_PIDS="$BUSY_PIDS $BUSY_PID"

    echo "Policy: $(cat $RTES_DIR/partition_policy)"
    echo "Tasks (C, T): (300, 1000), (200, 2000), (250, 4000), (200, 600), (150, 700), (100, 800)"

    local REF_FREQ=475 # (250,4000 + 150,700: 0.2857 * 1200 => 343
    local FREQ=$(head -1 $RTES_DIR/freq)
    for pid in $BUSY_PIDS
    do
        ./tools/rsvmgr cancel $pid
    done
    kill $BUSY_PIDS
    #killall busyloop
    check_freq $FREQ $REF_FREQ
}

test_nop()
{
    return 0
}

test_help()
{
    echo "freq_tracking : tests /sys/rtes/freq"
    echo "pwr_one_cpu_many_freqs"
    echo "pwr_many_cpus_many_freqs"
    echo "sysclock_min"
    echo "sysclock_max"
    echo "sysclock_one_cpu_1"
    echo "sysclock_one_cpu_2"
    echo "sysclock_one_cpu_3"
    echo "sysclock_two_cpu_lst"
    echo "partition_lst : requires /sys/rtes/reserves"

    echo "energy_max_freq_many_u"
    
    echo "energy_sum_two_diff_cpu"
    echo "energy_sum_many"

    echo "energymon_heavy"
    echo "energymon_light"
    echo "energymon_freqs_android_app"
}

if ps | grep -v grep | grep -q busyloop
then
    killall busyloop
fi

if [ "$#" -lt 1 -o "$1" = "help" ]
then
    test_help
    exit 0
fi

# System setup
echo 0 > /sys/module/cpu_tegra3/parameters/auto_hotplug
CPUS="0 1 2 3"
CPU_DIR=/sys/devices/system/cpu
for i in $CPUS
do
    CPU_PATH=$CPU_DIR/cpu$i
    if [ "$(cat $CPU_PATH/online)" -ne 1 ]
    then
        echo 1 > $CPU_PATH/online
    fi
    sleep 0.5
    echo userspace > $CPU_PATH/cpufreq/scaling_governor
    echo 1300000 > $CPU_PATH/cpufreq/scaling_setspeed
done

# Workaround for frequency changing upon bringing CPUs online/offline
CPU_DIR=/sys/devices/system/cpu
for i in $CPUS
do
    CPU_PATH=$CPU_DIR/cpu$i
    echo 1300000 > $CPU_PATH/cpufreq/scaling_max_freq
done

# Turn off other three CPUs
for i in 1 2 3
do
    CPU_PATH=$CPU_DIR/cpu$i
    if [ -e $CPU_PATH/online ]
    then
        echo 0 > $CPU_PATH/online
    fi
done

# CPU status
echo CPU status
for i in 0 1 2 3
do
    CPU_PATH=$CPU_DIR/cpu$i
    if [ "$(cat $CPU_PATH/online)" -ne 0 ]
    then
        CUR_GOV=$(cat $CPU_PATH/cpufreq/scaling_governor)
        CUR_FREQ=$(cat $CPU_PATH/cpufreq/scaling_cur_freq)
        echo CPU$i": " $CUR_GOV " " $CUR_FREQ
    fi
done

echo 1 > $RTES_DIR/config/energy

sleep 0.5

TEST=$1
shift
test_$TEST $@
if [ "$?" -ne 0 ]
then
    echo "Test $TEST failed"
    exit 1
fi
echo "Test $TEST passed"
