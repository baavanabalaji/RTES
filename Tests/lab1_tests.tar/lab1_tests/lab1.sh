#!/sbin/bash
#18-648 Lab 1 Test Script (2017)


TOOLS_DIR=tools

HELLO_BINARY=./hello
HELLO_MOD_BINARY=./hello.ko
CALC_BINARY=./calc
CLEANUP_MOD_BINARY=./cleanup.ko
PSDEV_MOD_BINARY=./psdev.ko

# For testing the test script without a psdev module:
# use ps to create a file with process list
#PSDEV_MKDEV_IMPL=ps
PSDEV_MKDEV_IMPL=mknod

PSDEV_PATH=/dev/psdev

remove_module()
{
    MOD_BINARY=$1
    MOD_FILE=$(basename "$MOD_BINARY")
    MOD_NAME="${MOD_FILE%.*}"
    rmmod $MOD_NAME
    if [ "$?" -ne 0 ]
    then
        echo "rmmod failed"
        return 1
    fi
}

test_hello_prog()
{
    HELLO_OUT=`$HELLO_BINARY`
    if [ "$?" -ne 0 ]
    then
        echo "Non-zero return code from binary '$HELLO_BINARY'"
        return 1
    fi

    OUT_REGEXP="hello.*warm.*cozy.*user.*space"
    echo $HELLO_OUT | grep -iEcq $OUT_REGEXP
    if [ "$?" -ne 0 ]
    then
        echo "Output does not match expected output: "
        echo "    Got: $HELLO_OUT"
        echo "    Expected (regexp): $OUT_REGEXP"
        return 1
    fi

    return 0
}

test_hello_lkm_common()
{
    MOD_BINARY=$HELLO_MOD_BINARY

    insmod $MOD_BINARY &
    wait $!
    if [ "$?" -ne 0 ]
    then
        echo "insmod $MOD_BINARY failed"
        return 1
    fi

    OUT_REGEXP="hello.*world.*kernel.*space.*free.*brave"
    dmesg | grep -icEq $OUT_REGEXP
    if [ "$?" -ne 0 ]
    then
        echo "Expected kernel log output not found"
        echo "    Expected (regexp): $OUT_REGEXP"
        remove_module $MOD_BINARY
        return 1
    fi

    remove_module $MOD_BINARY

    return 0
}

test_hello_lkm_one()
{
    test_hello_lkm_common
}

test_hello_lkm_many()
{
    LOAD_UNLOAD_ITERS=20
    for i in `seq 1 $LOAD_UNLOAD_ITERS`
    do
        test_hello_lkm_common
    done
}

check_res()
{
    ARG1=$1
    ARG2=$2
    OP="$3"

    # 10-bits means 1/2**10 = 0.0009, but we round it to 0.001 and
    # since the addition and subtraction compound the error, we double it.
    # Multiplication can multipy the error by the size of the operand,
    # so we should just use small numbers to avoid that. We test number
    # representation using dedicated +0 tests.
    if [ "$OP" = '*' -o "$OP" = '/' ]
    then
        TOLERANCE=0.010
    else
        TOLERANCE=0.002
    fi

    RES=$($CALC_BINARY $ARG1 "$OP" $ARG2)
    CALC_RC=$?

    NUM_TOTAL=$(($NUM_TOTAL+1))

#    if [ "$CALC_RC" -ne 0 ]
#    then
#        echo "FAIL: bad return code"
#        return 1
#   fi

    CHK_RES=$($TOOLS_DIR/fcalc $ARG2 $ARG1 "$OP" | tr '[:upper:]' '[:lower:]')

    NAN=0
    if [ "$CHK_RES" = "inf" -o "$CHK_RES" = "nan" ]
    then
        NAN=1
    else
        if [ "$CHK_RES" = "-inf" -o "$CHK_RES" = "-nan" ]
        then
            NAN=1
        fi
    fi

    if [ "$NAN" -eq 1 -a "$RES" != "nan" ]
    then
        echo "FAIL: result should be nan but is not"
        echo "    Test case: $ARG1 $OP $ARG2"
        echo "    Got                     : $RES"
        echo "    Floating-point reference: $CHK_RES"
        return 1
    else
        if [ "$NAN" -eq 0 ]
        then
            # Call the reference again but this time for checking tolerance
            CHK_RES_TOL=$($TOOLS_DIR/fcalc $ARG2 $ARG1 "$OP" $RES - a $TOLERANCE ">")
            if [ "$CHK_RES_TOL" -ne 1 ]
            then
                echo "FAIL: result not within tolerance ($TOLERANCE)"
                echo "    Test case: $ARG1 $OP $ARG2"
                echo "    Got                     : $RES"
                echo "    Floating-point reference: $CHK_RES"
                return 1
            fi
        fi
    fi

    NUM_PASSED=$(($NUM_PASSED+1))
}

test_calc()
{
    NUM_PASSED=0
    NUM_TOTAL=0

    check_res 0 0 +

    # Check number the precision of the number representation
    check_res 0 0.001 +
    check_res 0 0.1 +
    check_res 0 0.5 +
    check_res 0 0.125 +

    check_res 0 1 +
    check_res 0.0 1.0 +
    check_res 0.0 1.5 +

    check_res 2 2 +

    check_res 2 3 +
    check_res 3 1 -
    check_res 3 1 "*"
    check_res 5 1 /

    check_res 1 3 /

    check_res 2.5 3.1 +
    check_res 3.7 1.2 -
    check_res 1.4 2.1 "*"
    check_res 2.4 3.1 /

    check_res 0.5 0.5 "*"
    check_res 0.5 2 "*"
    check_res 0.4 2 /
    check_res 0.1 0.2 /

    # Check nan
    check_res 1 0 /
    check_res 1.2 0.0 /
    check_res 0 0 /

    if [ "$NUM_PASSED" -ne "$NUM_TOTAL" ]
    then
        return 1
    fi
    return 0
}

test_calc_app()
{
    CALC_BINARY=./calc
    test_calc
}

test_calc_syscall()
{
    CALC_BINARY=./tools/ta_calc
    test_calc
}

test_cleanup_one()
{
    MOD_BINARY=$CLEANUP_MOD_BINARY

    TEST_FAILED=0

    insmod $MOD_BINARY comm="sloppy"
    if [ "$?" -ne 0 ]
    then
        echo "insmod '$MOD_BINARY' failed"
        return 1
    fi

    FNAME=a-file-left-open-$(date +%s)

    $TOOLS_DIR/sloppy $FNAME &
    SLOPPY_PID=$!
    wait $SLOPPY_PID
    if [ "$?" -ne 0 ]
    then
        echo "sloppy reader returned a bad code"
        TEST_FAILED=1
    fi
    rm $FNAME

    dmesg | grep -nEq "sloppy.*$SLOPPY_PID.*close.*files"
    if [ "$?" -ne 0 ]
    then
        echo "FAIL: cannot find sloppy process report in kernel log"
        TEST_FAILED=1
    else
        dmesg | grep -nq $FNAME
        if [ "$?" -ne 0 ]
        then
            echo "FAIL: file left open not found in kernel log"
            TEST_FAILED=1
        fi
    fi

    remove_module $MOD_BINARY

    return $TEST_FAILED
}

test_cleanup_many()
{
    NUM_ITERATIONS=16
    for i in `seq 1 $NUM_ITERATIONS`
    do
        test_cleanup_one
        if [ "$?" -ne 0 ]
        then
            return 1
        fi
    done
}

launch_rt_process()
{
    RT_PRIO=$1
    chrt -r $RT_PRIO bash -c 'while true; do sleep 1; done' &
    RT_PID=$!
}

launch_rt_processes()
{
    NUM=$1
    RT_PROCESSES=""
    for i in `seq 1 $NUM`
    do
        launch_rt_process $i
        RT_PROCESSES="$RT_PROCESSES $RT_PID"
    done
}

kill_rt_processes()
{
    for pid in $RT_PROCESSES
    do
        kill $pid
        wait $pid
    done
}

mkdev_ps()
{
    DEV_INSTANCE_PATH=$1
    ps | grep bash > $DEV_INSTANCE_PATH
}

mkdev_mknod()
{
    DEV_INSTANCE_PATH=$1

    grep -qn psdev /proc/devices
    if [ "$?" -ne 0 ]
    then
        echo "FAIL: cannot find the psdev in /proc/devices"
        return 1
    fi

    PSDEV_MAJOR=`grep psdev /proc/devices | (tail -n1) | cut -d' ' -f1`
    PSDEV_MINOR=1

    echo mknod $DEV_INSTANCE_PATH  c $PSDEV_MAJOR $PSDEV_MINOR
    mknod $DEV_INSTANCE_PATH  c $PSDEV_MAJOR $PSDEV_MINOR
    if [ "$?" -ne 0 ]
    then
        echo "mknod '$DEV_INSTANCE_PATH c $PSDEV_MAJOR $PSDEV_MINOR' failed"
        return 1
    fi
}

mkdev()
{
    mkdev_$PSDEV_MKDEV_IMPL $@
}

rmdev()
{
    DEV_INSTANCE_PATH=$1
    rm $DEV_INSTANCE_PATH
    if [ "$?" -ne 0 ]
    then
        echo "rm '$DEV_INSTANCE_PATH' failed"
        return 1
    fi
}

psdev_insmod()
{
    insmod $PSDEV_MOD_BINARY
    if [ "$?" -ne 0 ]
    then
        echo "insmod '$PSDEV_MOD_BINARY' failed"
        return 1
    fi
}

psdev_rmmod()
{
    remove_module $PSDEV_MOD_BINARY
}

psdev_check_content()
{
    # Input in env vars: RT_PROCESSES and DEV_OUTPUT

    for pid in $RT_PROCESSES
    do
        echo $DEV_OUTPUT | grep -nq $pid
        if [ "$?" -ne 0 ]
        then
            echo "FAIL: expected process $pid not found in output"
            return 1
        fi
    done

    return 0
}

chunkdev()
{
    DEV_INSTANCE_PATH=$1
    CHUNK_SIZE=$2

    DEV_OUTPUT=`$TOOLS_DIR/chunkedcat $DEV_INSTANCE_PATH $CHUNK_SIZE`
    if [ "$?" -ne 0 ]
    then
        echo "chunkedcat $CHUNK_SIZE '$DEV_INSTANCE_PATH' failed"
        return 1
    fi

    psdev_check_content
}

catdev()
{
    DEV_INSTANCE_PATH=$1

    DEV_OUTPUT=`cat $DEV_INSTANCE_PATH`
    if [ "$?" -ne 0 ]
    then
        echo "cat '$DEV_INSTANCE_PATH' failed"
        return 1
    fi

    psdev_check_content
}


test_psdev_basic()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=5

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH
    catdev $DEV_INSTANCE_PATH
    TEST_RESULT=$?
    rmdev $DEV_INSTANCE_PATH

    kill_rt_processes
    psdev_rmmod
    return $TEST_RESULT
}

test_psdev_multiple_instances()
{
    NUM_INSTANCES=5
    DEV_INSTANCE_PREFIX=$PSDEV_PATH
    NUM_RT_PROCESSES=5

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    DEV_INDICES=`seq 1 $NUM_INSTANCES`

    TEST_FAILED=0

    for i in $DEV_INDICES
    do
        mkdev $DEV_INSTANCE_PREFIX$i
    done

    for i in $DEV_INDICES
    do
        catdev $DEV_INSTANCE_PREFIX$i
        if [ "$?" -ne 0 ]
        then
            TEST_FAILED=1
            break
        fi
    done

    for i in $DEV_INDICES
    do
        rmdev $DEV_INSTANCE_PREFIX$i
    done

    kill_rt_processes
    psdev_rmmod
    return $TEST_FAILED
}

psdev_check_errno()
{
    DEV_INSTANCE_PATH=$1
    OP=$2
    
    shift 2

    ERRNO=`$TOOLS_DIR/${OP}errno $DEV_INSTANCE_PATH`

    FOUND_MATCH=0
    for REF_ERRNO in $@
    do
        if [ "$ERRNO" -eq $REF_ERRNO ]
        then
            FOUND_MATCH=1
            break
        fi
    done

    if [ "$FOUND_MATCH" -eq 0 ]
    then
        echo "FAIL: ${OP} on device did not return expected errno"
        echo "     Got              : $ERRNO"
        echo "     Expected (any of): $@"
        return 1
    fi
    return 0
}

test_psdev_unsupported_ops()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=5

    EOPNOTSUPP_ERRNO=95 # EOPNOTSUPP from sys/errno.h
    ENOTSUPP_ERRNO=524 # ENOTSUPP from linux/errno.h
    EBADF_ERRNO=9

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH

    TEST_FAILED=0

    psdev_check_errno $DEV_INSTANCE_PATH write $EOPNOTSUPP_ERRNO $ENOTSUPP_ERRNO $EBADF_ERRNO
    if [ "$?" -ne 0 ]
    then
        TEST_FAILED=1
    fi

    rmdev $DEV_INSTANCE_PATH
    kill_rt_processes
    psdev_rmmod

    return $TEST_FAILED
}

test_psdev_chunked()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=10
    CHUNK_SIZE=16

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH

    chunkdev $DEV_INSTANCE_PATH $CHUNK_SIZE
    TEST_RESULT=$?

    rmdev $DEV_INSTANCE_PATH
    kill_rt_processes
    psdev_rmmod

    return $TEST_RESULT
}

psdev_open_and_check_ebusy()
{
    $TOOLS_DIR/holdopen $DEV_INSTANCE_PATH &
    HOLDOPEN_PID=$!
    sleep 2 # must wait until holdopen actually opens the file

    psdev_check_errno $DEV_INSTANCE_PATH open $EBUSY_ERRNO
    TEST_RESULT=$?

    kill $HOLDOPEN_PID
    wait $HOLDOPEN_PID

    return $TEST_RESULT
}

test_psdev_open_limit()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=5

    EBUSY_ERRNO=16 # from errno-base.h

    TEST_RESULT=0

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH

    psdev_open_and_check_ebusy $DEV_INSTANCE_PATH
    if [ "$?" -ne 0 ]
    then
        TEST_RESULT=1
    fi

    rmdev $DEV_INSTANCE_PATH
    psdev_rmmod

    return $TEST_RESULT
}

test_psdev_open_limit_two()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=5

    EBUSY_ERRNO=16 # from errno-base.h

    TEST_RESULT=0

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH

    psdev_open_and_check_ebusy $DEV_INSTANCE_PATH && \
        psdev_check_errno $DEV_INSTANCE_PATH open 0 && \
        psdev_open_and_check_ebusy $DEV_INSTANCE_PATH

    if [ "$?" -ne 0 ]
    then
        TEST_RESULT=1
    fi

    rmdev $DEV_INSTANCE_PATH
    psdev_rmmod

    return $TEST_RESULT
}

test_psdev_cleanup()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=5
    NUM_ITERS=5

    launch_rt_processes $NUM_RT_PROCESSES

    for i in `seq 1 $NUM_ITERS`
    do
        # ins/rm-mod and mk/rm-dev are interleaved on purpose: don't want any
        # dangling resources even if there's a mkdev file with the driver's
        # major number still around.
        # TODO: de-interleave by pulling out mkdev as the first op. To do that
        # need to factor getting the major number out.
        psdev_insmod
        mkdev $DEV_INSTANCE_PATH
        psdev_rmmod
        rmdev $DEV_INSTANCE_PATH

        TEST_FAILED=0
        NUM_REGS=`grep -nqc psdev /proc/devices`
        if [ "$NUM_REGS" -ne 0 ]
        then
            TEST_FAILED=1
            break
        fi
    done

    kill_rt_processes
    return $TEST_FAILED
}

psdev_cat_stresser()
{
    DEV_INSTANCE_PATH=$1
    while true
    do
        DEV_OUTPUT=`cat $DEV_INSTANCE_PATH 2>/dev/null`
        if [ "$?" -eq 0 ] # ignore open errors, but on success check content
        then
            psdev_check_content
            if [ "$?" -ne 0 ]
            then
                return 1
            fi
        fi
    done
}

test_psdev_stress_cat()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_RT_PROCESSES=10
    NUM_STRESSERS=16
    DURATION_SEC=10

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES

    mkdev $DEV_INSTANCE_PATH

    STRESSER_PIDS=""
    for i in `seq 1 $NUM_STRESSERS`
    do
        psdev_cat_stresser $DEV_INSTANCE_PATH &
        STRESSER_PID=$!
        STRESSER_PIDS="$STRESSER_PIDS $STRESSER_PID"
    done

    sleep $DURATION_SEC

    TEST_FAILED=0
    for pid in $STRESSER_PIDS
    do
        kill $pid
        wait $pid
        if [ "$?" -lt 128 ] # process NOT terminated by a signal
        then
            TEST_FAILED=1
        fi
    done

    rmdev $DEV_INSTANCE_PATH
    kill_rt_processes
    psdev_rmmod

    return $TEST_FAILED
}

test_psdev_concurrent_access()
{
    DEV_INSTANCE_PATH=$PSDEV_PATH
    NUM_WORKERS=16
    DURATION_SEC=30
    CHUNK_SIZE=32

    psdev_insmod
    launch_rt_processes $NUM_RT_PROCESSES
    mkdev $DEV_INSTANCE_PATH

    $TOOLS_DIR/concurrentreader $DEV_INSTANCE_PATH $NUM_WORKERS $CHUNK_SIZE $DURATION_SEC

    rmdev $DEV_INSTANCE_PATH
    kill_rt_processes
    psdev_rmmod
}

test_rt_processes()
{
    NUM_PROCESSES=16
    launch_rt_processes $NUM_PROCESSES
    echo kill $RT_PROCESSES
    wait
}

test_all()
{
    test_hello_prog
    test_hello_lkm_one
    test_hello_lkm_many
    test_calc_app
    test_calc_syscall
    test_cleanup_one
    test_cleanup_many
    test_psdev_basic
    test_psdev_chunked
    test_psdev_unsupported_ops
    test_psdev_open_limit
    test_psdev_multiple_instances
    test_psdev_concurrent_access
    test_rt_processes
}

test_help()
{
    echo "all"
    echo "hello_prog"
    echo "hello_lkm_one"
    echo "hello_lkm_many"
    echo "calc_app"
    echo "calc_syscall"
    echo "cleanup_one"
    echo "cleanup_many"
    echo "psdev_basic"
    echo "psdev_chunked"
    echo "psdev_cleanup"
    echo "psdev_unsupported_ops"
    echo "psdev_open_limit"
    echo "psdev_open_limit_two"
    echo "psdev_multiple_instances"
    echo "psdev_stress_cat"
    echo "psdev_concurrent_access"
    echo "rt_processes"
}

if [ "$1" = "help" ]
then
    test_help
    exit 0
fi

TEST=$1
shift
test_$TEST $@
if [ "$?" -ne 0 ]
then
    echo "Test $TEST failed"
    exit 1
fi
echo "Test $TEST passed"
exit 0
