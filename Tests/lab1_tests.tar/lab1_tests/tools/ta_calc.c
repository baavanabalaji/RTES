#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <asm/unistd.h>
#include <sys/syscall.h>
#include <linux/kernel.h>

#define SIZE 32

#if !defined(__NR_sys_calc) && !defined(__NR_calc)
#error cannot find calc syscall NR
#endif

#ifdef __NR_sys_calc
#define calc_sysnr __NR_sys_calc
#else
#define calc_sysnr __NR_calc
#endif

long sys_calc(const char* param1, const char* param2, char operation,
              char* result) {
    return syscall(calc_sysnr, param1, param2, operation, result);
}

int main(int argc, char* argv[]) {
    const char* p1;
    const char* p2;
    char* res;
    char op;
    long ret;

    if (argc != 4) {
        printf("nan\n");
        return 0;
    }

    p1 = argv[1];
    op = argv[2][0];
    p2 = argv[3];
    res = malloc(SIZE);

    ret = sys_calc(p1, p2, op, res);
    if (!ret) {
        printf("%s\n", res);
    } else {
        printf("nan\n");
    }

    free(res);
    return 0;
}
