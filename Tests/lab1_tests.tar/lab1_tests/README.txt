18-648 Lab 1 Tests (2017)

Overview:

This package consists of the test script (lab1.sh), required TA binaries as well as TA source files for tests that need to be compiled against
user headers exported by you.


Files:

lab1.sh - Contains the following tests

hello_prog
Tests basic output to stdout from user application.

hello_lkm_one
Tests basic output to dmesg from kernel module. 

hello_lkm_many
Tests multiple invocations of insert & delete of kernel module and checks their output to dmesg from kernel module. 

calc_app
Tests students' user application and the output of calculation operations passed into the test application.

calc_syscall
Tests students' calc syscall using ta_calc binary built on students' exported user headers. 

cleanup_one
Tests output from cleanup module when an application (sloppy) runs and leaves one open file before exit, after cleanup is inserted.

cleanup_many
Tests cleanup_one multiple times.

psdev_basic
Inserts psdev, and makes 1 single psdev device instance and checks the return value from cating that file.

psdev_chunked
Inserts psdev, launches a few real-time processes and makes 1 single psdev device instance. Then it reads from the device file in chunk-sized byte blocks and also checks that all pids created by test are present in output.

psdev_cleanup
Inserts psdev, makes a device instance, removes psdev and then checks to make sure that the device does not show up in /proc/devices for psdev. 

psdev_unsupported_ops
Inserts psdev, makes a device instance and writes to it. Checks for the expected return value on a write to a psdev device instance. 

psdev_open_limit
Inserts psdev, makes a device instance, and has one process open the device file indefinitely. Then, opens in another process to check for the required return value.

psdev_open_limit_two
Tests the psdev_open_limit multiple times.

psdev_multiple_instances
Inserts psdev, creates a few real-time processes, makes a few device instances of a single device and then cats from each device instance.

psdev_stress_cat
Inserts psdev, creates a few real-time processes, makes a device instance, and then cats the file in multiple processes, concurrently.

psdev_concurrent_access
Inserts psdev, launches a few real-time processes, makes a device instance, and opens in a process. Then it makes two pthreads in that process, and each thread reads from the device file using the same open file descriptor concurrently.

rt_processes
Starts a few rt_processes and prints their pids to check rtps.


Usage:

In order to run the tests on your applications and modules, place the
following user binaries & built modules in the same directory as lab1.sh.

HELLO_BINARY - hello
HELLO_MOD_BINARY - hello.ko
CALC_BINARY - calc
CLEANUP_MOD_BINARY - cleanup.ko
PSDEV_MOD_BINARY - psdev.ko

In order to run the TA binaries, leave them in the tools directory (created in the same directory as lab1.sh) as in this package. Build the ta_calc application using the Makefile in the tools directory, after pointing the EXP_HDRS variable to the correct location of your usr/include folder.
