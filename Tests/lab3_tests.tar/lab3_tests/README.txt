
Note: Autohotplugging disabling and core enabling is done upon entry for each test.
Note: All times in this document are in milliseconds, unless stated otherwise.
Tasks are denoted as (C,T, CORE)

enforce_2 : checks enforcement by running busyloop and then setting a reserve on it. With parameters C = 100 ms and T = 1000 ms.

easyperiodic_util_light: Will launch an easyperiodic task using the student’s easyperiodic. C and T are 100 and 500 respectively. Will set a reservation on the task with C and T of 100 and 500, as well (with a small buffer of 20 ms). Then, it will enable monitoring, sleep for 4 seconds, check if the utilization file exists, copy it to a local file, and then read each data point from that file and ensure that it is within 10% of the expected utilization (C/T).

easyperiodic_util_med: Will launch an easyperiodic task using the student’s easyperiodic. C and T are 200 and 500 respectively. Will set a reservation on the task with C and T of 200 and 500, as well (with a small buffer). Then, it will enable monitoring, sleep for 4 seconds, check if the utilization file exists, copy it to a local file, and then read each data point from that file and ensure that it is within 10% of the expected utilization (C/T).

easyperiodic_util_heavy: Will launch an easyperiodic task using the student’s easyperiodic. C and T are 450 and 500 respectively (with a small buffer). Will set a reservation on the task with C and T of 450 and 500, as well. Then, it will enable monitoring, sleep for 4 seconds, check if the utilization file exists, copy it to a local file, and then read each data point from that file and ensure that it is within 10% of the expected utilization (C/T).

reserve_status: Launches 4 busylooping tasks and sets them to ascending priorities, starting at 50. Puts each task on core 0, 1, 2, 3. Then, it sets a reservation on each of them, with C = 50 and T = 500. After this is done, it will copy the reserves file (file listing all threads with active reservation). Then, we will check the copy of the file to ensure that they’ve given us the task name, pid, and cpu number. Ignoring priority because of RMS/the previous TAs seem to also have ignored it. The tasks are then killed.

accept_taskset: simply call check_taskset with whatever arguments are passed to it.

launch_reserved_taskset: Given a task, it will launch a sleeploop application with the given C and T for the task, and set a reservation on the sleeploop with the same C and T values. Sleeploop will repeatedly call sleep for 1 second.

check_taskset: Launches a launch_reserved_sleep task for each task in the taskset. After doing this, we sleep for two seconds, and then look for the sleeploop tasks in the that were made from the taskset, and check to make sure that they exist via the reserves file. Then it may cancel the threads. Then it will kill the threads.

reject_taskset: will return success (0) when the taskset is not schedulable

adm_single_cpu_accept_1: call accept_taskset on taskset = {(250, 500, 0)}. 
Adm_single_cpu_accept_u_2: call accept_taskset on taskset = {(200,500,0), (100,300,0)} basically testing if they’ve done UB test correctly. This is below U(2) = 0.828

Adm_single_cpu_reject_2: call reject_taskset on taskset = {(250,500,0),(300,500,0)}. Should be rejected because util is 1.1 on a single core.

Adm_single_cpu_accept_u_3: call accept_taskset on taskset = {(200,500,0), (150,600,0), (40, 400,0)} basically testing if they’ve done UB test correctly. This is below U(3) = 0.779

Adm_single_cpu_accept_u_5: call accept_taskset on taskset = {(20,600,0), (60,500,0), (100, 450,0), (30, 300, 0), (50, 200,0)} basically testing if they’ve done UB test correctly. This is below U(5) = 0.743

Adm_single_cpu_accept_h_2: call accept_taskset on harmonic taskset = {(250,500,0), (125,250,0)}. Harmonic ⇒ Ubound = 1

Adm_single_cpu_accept_h_3: call accept_taskset on harmonic taskset = {(200,400,0), (50,200,0), (25,100,0)}. Harmonic ⇒ Ubound = 1

Adm_single_cpu_accept_h_10: call accept_taskset on harmonic taskset = {(200,2000,0), 
(100,1000,0),
(100,1000,0),
(50,500,0),
(25,250,0),
(200,2000,0),
(100,1000,0),
(100,1000,0),
(50,500,0),
(25,250,0),}. Harmonic ⇒ Ubound = 1

adm_single_cpu_accept_r_2: call accept_taskset on taskset = {(200,500,0), (100,300,0)}. This will make the UB test inconclusive, so it’ll test if they’ve implemented the RT test correctly

adm_single_cpu_accept_r_3: call accept_taskset on taskset = {(10,40,0), (20,60,0), (25,100,0)}. This will make the UB test inconclusive, so it’ll test if they’ve implemented the RT test correctly.

Adm_bin_packing_nfd_success_1: Will use the next fit heuristic to schedule the following schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(30,300,-1)}
adm_bin_packing_nfd_fail_1: Will use the next fit heuristic to attempt to schedule the not schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(30,300,-1),(410,1000,-1))}
adm_bin_packing_bfd_success_1:Will use the best fit heuristic to schedule the following schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(30,300,-1),(80,200,-1)}
Adm_bin_packing_bfd_fail_1:Will use the best fit heuristic to attempt to schedule the not schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(30,300,-1),(80,200,-1),(90,300,-1)}
adm_bin_packing_wfd_success_1: Will use the worst fit heuristic to schedule the following schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(40,400,-1),(20,100,-1)}
Adm_bin_packing_wfd_fail_1: Will use the worst fit heuristic to attempt to schedule the not schedulable taskset: 
{(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(40,200,-1),(20,50,-1),(40,400,-1),(40,100,-1)}
adm_bin_packing_ffd_success_1:Will use the first fit heuristic to schedule the following schedulable taskset: {(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(20,50,-1),(40,400,-1),(40,200,-1),(20,100,-1)}
Adm_bin_packing_ffd_fail_1: Will use the worst fit heuristic to attempt to schedule the not schedulable taskset: 
{(40,50,-1),(50,100,-1),(140,200,-1),(60,100,-1),(20,50,-1),(40,400,-1),(40,200,-1),(20,100,-1),(30,100,-1)}

Usage:

In order to run the tests on your applications and modules, place the
following user binaries & built modules in the same directory as lab3.sh.

EASYPERIODIC_BINARY - Student easyperiodic binary

In order to run the TA binaries, leave them in the tools directory (created in the same directory as lab3.sh) as in this package. Build the TA rsvmgr application using the Makefile in the tools directory, after pointing the EXP_HDRS variable to the correct location of your usr/include folder. Please run only the tests that are outlined in this document.
