#!/sbin/bash

TOOLS_DIR=tools

STATUS_FILE=/sys/rtes/reserves
ENABLE_TASKMON_FILE=/sys/rtes/taskmon/enabled
CANCEL_RESERVE=1
TASKMON_PATH=/sys/rtes/taskmon

do_test()
{
    local TEST_NAME=$1
    test_$TEST_NAME
    if [ "$?" -ne 0 ]
    then
        echo "Test $TEST_NAME failed"
        exit 1
    fi
}

check_suspension()
{
    local COUNT_PID=$1
    local COUNT_FILE=$2

    if ! [ -r $COUNT_FILE ]
    then
        echo "FAILED: counter file not found: $COUNT_FILE"
        return 1
    fi

    COUNT_1=$(cat $COUNT_FILE)
    sleep 1
    COUNT_2=$(cat $COUNT_FILE)
    sleep 5
    COUNT_3=$(cat $COUNT_FILE)
    if [ $COUNT_2 -ne $COUNT_1 ]
    then
        echo "FAILED: task was not suspended ($COUNT_1, $COUNT_2)"
        return 1
    fi
    if [ $COUNT_3 -eq $COUNT_1 ]
    then
        echo "FAILED: task did not resume ($COUNT_2, $COUNT_3)"
        return 1
    fi
    return 0
}

#UNUSED IN FALL 2017 TEST SUITE
test_enforce()
{
    local TEST_RESULT=0
    local COUNT_FILE=countfile.$$
    chrt -f 50 $TOOLS_DIR/count sleep 10000000 0 $COUNT_FILE &
    COUNT_PID=$!
    sleep 0.5
    ./tools/rsvmgr set $COUNT_PID 10 5000 0
    sleep 0.5
    if ! check_suspension $COUNT_PID $COUNT_FILE
    then
        TEST_RESULT=1
    fi
    kill $COUNT_PID
    return $TEST_RESULT
}

check_util_data()
{
    local PERIODIC_PID=$1
    local NUM_LINES_REF=$2
    local UTIL_REF=$3

    local UTIL_FILE=$TASKMON_PATH/util/$PERIODIC_PID
    if ! [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file not found: '$UTIL_FILE'" 1>&2
        return 1
    fi

    mkdir -p tmp
    local UTIL_TMP_FILE=tmp/$$-util-$PERIODIC_PID
    cat $UTIL_FILE > $UTIL_TMP_FILE
    local NUM_LINES=$(wc -l $UTIL_TMP_FILE | cut -d' ' -f1)
    if [ "$NUM_LINES" -lt $NUM_LINES_REF ]
    then
        echo "FAILED: too few data points: $NUM_LINES" 1>&2
        return 1
    fi

    local LINE=0
    while read p
    do
        LINE=$((LINE+1))
        if [ "$LINE" -eq 1 ]
        then
            continue
        fi
        TOLERANCE=0.05
        UTIL="$(echo $p | cut -d' ' -f2)" 
        RESULT=$($TOOLS_DIR/fcalc $UTIL $UTIL_REF - 'a' $TOLERANCE '<')
        if [ "$RESULT" -ne 0 ]
        then
            echo "FAILED: utilization not within $TOLERANCE of $UTIL_REF: $UTIL" 1>&2
            return 1
        fi
    done < $UTIL_TMP_FILE
    rm $UTIL_TMP_FILE
    return 0
}


test_enforce_2()
{
    local UTIL_REF=0.1 # change this if changing the following
    chrt -f 50 $TOOLS_DIR/busyloop &
    local PERIODIC_PID=$!
    sleep 1
    $TOOLS_DIR/rsvmgr set $PERIODIC_PID 100 1000 0
    echo 1 > $ENABLE_TASKMON_FILE
    sleep 6
    echo 0 > $ENABLE_TASKMON_FILE
    sleep 2
    NUM_LINES_REF=5
    if ! check_util_data $PERIODIC_PID $NUM_LINES_REF $UTIL_REF
    then
        return 1
    fi
    $TOOLS_DIR/rsvmgr cancel $PERIODIC_PID
    sleep 1
    if [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file still exists: '$UTIL_FILE'" 1>&2
        return 1
    fi
    kill $PERIODIC_PID
    return 0
}

#Unused in Fall 2017 Test Suite
test_end_job()
{
    local TEST_RESULT=0
    COUNT_FILE=countfile.$$
    chrt -f 50 $TOOLS_DIR/count reserve 10000000 5000 $COUNT_FILE &
    COUNT_PID=$!
    sleep 0.5
    if ! check_suspension $COUNT_PID $COUNT_FILE
    then
        TEST_RESULT=1
    fi
    if [ "$CANCEL_RESERVE" = 1 ]
    then
        ./tools/rsvmgr cancel $COUNT_PID
    fi
    kill $COUNT_PID
    return $TEST_RESULT
}

#Unused in Fall 2017 Test Suite
test_enforce_no_signal()
{
    local TEST_RESULT=0
    local COUNT_FILE=countfile.$$
    chrt -f 50 $TOOLS_DIR/count sleep 10000000 0 $COUNT_FILE &
    COUNT_PID=$!
    ./tools/rsvmgr set $COUNT_PID 10 5000 0
    sleep 1

    kill -SIGUSR2 $COUNT_PID
    sleep 0.5

    #if ! ps | grep -q $COUNT_PID
    if ! [ -e /proc/$COUNT_PID ]
    then
        echo "FAILED: task handled signal"
        TEST_RESULT=1
    fi

    if [ "$CANCEL_RESERVE" = 1 ]
    then
        ./tools/rsvmgr cancel $COUNT_PID
    fi
    kill $COUNT_PID
    return $TEST_RESULT
}

check_easyperiodic_util()
{
    local C=$1
    local T=$2
    local TEST_RESULT=0
    local UTIL_REF=$($TOOLS_DIR/fcalc $T $C '/' )
    ./easyperiodic $C $T 0 &
    local PERIODIC_PID=$!
    sleep 0.5
    ./tools/rsvmgr set $PERIODIC_PID $(($C+20)) $T 0
    echo 1 > $ENABLE_TASKMON_FILE
    sleep 4
    local UTIL_FILE=/sys/rtes/taskmon/util/$PERIODIC_PID
    if ! [ -e $UTIL_FILE ]
    then
        echo "FAILED: utilization file not found ($UTIL_FILE)"
        echo 0 > $ENABLE_TASKMON_FILE
        kill $PERIODIC_PID
        return 1
    fi
    local UTIL_SNAPSHOT=util.$PERIODIC_PID
    cp $UTIL_FILE $UTIL_SNAPSHOT
    echo 0 > $ENABLE_TASKMON_FILE

    local LINE=0
    while read p
    do
        LINE=$((LINE+1))
        if [ "$LINE" -eq 1 ]
        then
            continue
        fi
        local TOLERANCE=0.10
        local UTIL="$(echo $p | cut -d' ' -f2)" 
        local RESULT=$($TOOLS_DIR/fcalc $UTIL $UTIL_REF - 'a' $TOLERANCE '<')
        if [ "$RESULT" -ne 0 ]
        then
            echo "FAILED: utilization not within $TOLERANCE of $UTIL_REF: $UTIL" 1>&2
            TEST_RESULT=1
            break
        fi
    done < $UTIL_SNAPSHOT

    if [ "$TEST_RESULT" -eq 0 ]
    then
        if [ "$LINE" -lt 1 ]
        then
            echo "FAILED: no data points in utilization file"
            return 1
        fi
    fi

    kill $PERIODIC_PID
    return $TEST_RESULT
}

test_easyperiodic_util_light()
{
    check_easyperiodic_util 100 500
}
test_easyperiodic_util_med()
{
    check_easyperiodic_util 200 500
}
test_easyperiodic_util_heavy()
{
    check_easyperiodic_util 450 500
}

test_reserve_status()
{
    local PRIO_BASE=50

    local BUSY_PIDS=""
    for i in 0 1 2 3
    do
        local CPU=$i
        local PRIO=$(($PRIO_BASE+$i))
        chrt -f $PRIO $TOOLS_DIR/busyloop &
        local BUSY_PID=$!
        BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
        ./tools/rsvmgr set $BUSY_PID 50 500 $CPU
    done

    local STATUS_SNAPSHOT=reserves.$$
    cp $STATUS_FILE $STATUS_SNAPSHOT
    cat $STATUS_SNAPSHOT

    local TEST_RESULT=0
    local i=0
    for pid in $BUSY_PIDS
    do
        local CPU=$i
        local PRIO=$(($PRIO_BASE + $i))

        local FOUND=0
        while read p
        do
            if echo $p | grep -q $pid
            then
                FOUND=1
                break
            fi
        done < $STATUS_SNAPSHOT

        if [ $FOUND -eq 0 ]
        then
            echo "FAILED: task PID not found in status file ($STATUS_FILE)"
            TEST_RESULT=1
            break
        fi

        if ! echo $p | grep -q busyloop
        then
            echo "FAILED: task name not found in status line ($STATUS_FILE)"
            TEST_RESULT=1
            break
        fi

        # The priority p shows up as (p-1): need to investigate whether that is
        # expected, and if so, then change this test to test for (p-1)
        #if ! echo $p | grep -q -E "[ \\t]+$PRIO[ \\t]+"
        #then
            #echo "FAILED: task priority not found in status line"
            #TEST_RESULT=1
            #break
        #fi

        if ! echo $p | grep -q -E "[ \\t]+$CPU[ \\t]+"
        then
            echo "FAILED: task cpu not found in status line ($STATUS_FILE)"
            TEST_RESULT=1
            break
        fi

        i=$(($i + 1))
    done

    if [ "$CANCEL_RESERVE" = 1 ]
    then
        for pid in $BUSY_PIDS
        do
            ./tools/rsvmgr cancel $pid
        done
    fi
    kill $BUSY_PIDS
    return $TEST_RESULT
}

check_reserves()
{
    local PIDS="$*"
    cp $STATUS_FILE status.$$
    for PID in $PIDS
    do
        local FOUND=0
        while read p
        do
            if echo $p | grep -q $PID
            then
                FOUND=1
                break
            fi
        done < $STATUS_FILE

        if [ $FOUND -ne 1 ]
        then
            return 1
        fi
    done
    return 0
}

launch_reserved_sleep()
{
    local ARGS="$1"
    local CPU=$(echo $ARGS | cut -d'_' -f1)
    local C=$(echo $ARGS | cut -d'_' -f2)
    local T=$(echo $ARGS | cut -d'_' -f3)
    chrt -f 50 $TOOLS_DIR/sleeploop $C $T &
    BUSY_PID=$!
    BUSY_PIDS="$BUSY_PIDS $BUSY_PID"
    ./tools/rsvmgr set $BUSY_PID $C $T $CPU
}

check_taskset()
{
    local TASKSET="$*"
    echo TASKSET="$TASKSET"
    local TEST_RESULT=0
    BUSY_PIDS=""
    for task in $TASKSET
    do
        launch_reserved_sleep "$task"
    done
    sleep 2
    ps | grep sleeploop > status_ps.$$
    if ! check_reserves $BUSY_PIDS
    then
        echo "FAILED: expected reserves not found in status"
        TEST_RESULT=1
    fi
    if [ "$CANCEL_RESERVE" = 1 ]
    then
        for pid in $BUSY_PIDS
        do
            ./tools/rsvmgr cancel $pid
            sleep 0.5
        done
    fi
    kill $BUSY_PIDS
    sleep 1
    return $TEST_RESULT
}

test_nop()
{
    return 0
}

accept_taskset()
{
    check_taskset $*
}

reject_taskset()
{
    if check_taskset $*
    then
        return 1
    fi
    return 0
}

test_adm_single_cpu_accept_1()
{
    accept_taskset \
        "0_250_500"
}

test_adm_single_cpu_accept_u_2()
{
    accept_taskset \
        "0_200_500" \
        "0_100_300"
}

test_adm_single_cpu_reject_2()
{
    reject_taskset \
        "0_250_500" \
        "0_300_500"
}

test_adm_single_cpu_accept_u_3()
{
    accept_taskset \
        "0_200_500" \
        "0_150_600" \
        "0_40_400"
}

test_adm_single_cpu_accept_u_5()
{
    accept_taskset \
        "0_20_600" \
        "0_60_500" \
        "0_100_450" \
        "0_30_300" \
        "0_50_200"
}

test_adm_single_cpu_accept_h_2()
{
    accept_taskset \
        "0_250_500" \
        "0_125_250"
}

test_adm_single_cpu_accept_h_3()
{
    accept_taskset \
        "0_200_400" \
        "0_50_200" \
        "0_25_100"
}

test_adm_single_cpu_accept_h_10()
{
    accept_taskset \
        "0_200_2000" \
        "0_100_1000" \
        "0_100_1000" \
        "0_50_500" \
        "0_25_250" \
        "0_200_2000" \
        "0_100_1000" \
        "0_100_1000" \
        "0_50_500" \
        "0_25_250"
}

test_adm_single_cpu_accept_r_2()
{
    accept_taskset \
        "0_20_50" \
        "0_40_80" 
}

test_adm_single_cpu_accept_r_3()
{
    accept_taskset \
        "0_10_40" \
        "0_20_60" \
        "0_25_100" 
}

PARTITION_POLICY_FILE=/sys/rtes/partition_policy

test_adm_bin_packing_nfd_success_1()
{
    echo NF > $PARTITION_POLICY_FILE
    accept_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_30_300" 
}

test_adm_bin_packing_nfd_fail_1()
{
    echo NF > $PARTITION_POLICY_FILE
    reject_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_30_300" \
        "-1_410_1000"
}

test_adm_bin_packing_bfd_success_1()
{
    echo BF > $PARTITION_POLICY_FILE
    accept_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_30_300" \
	    "-1_80_200"
}

test_adm_bin_packing_bfd_fail_1()
{
    echo BF > $PARTITION_POLICY_FILE
    reject_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_30_300" \
	    "-1_80_200" \
	    "-1_90_300"
}

test_adm_bin_packing_wfd_success_1()
{
    echo WF > $PARTITION_POLICY_FILE
    accept_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_40_400" \
        "-1_20_100" 
}

test_adm_bin_packing_wfd_fail_1()
{
    echo WF > $PARTITION_POLICY_FILE
    reject_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_40_200" \
        "-1_20_50" \
        "-1_40_400" \
	    "-1_40_100" 
}

test_adm_bin_packing_ffd_success_1()
{
    echo FF > $PARTITION_POLICY_FILE
    accept_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_20_50" \
        "-1_40_400" \
        "-1_40_200" \
        "-1_20_100" 
}

test_adm_bin_packing_ffd_fail_1()
{
    echo FF > $PARTITION_POLICY_FILE
    reject_taskset \
        "-1_40_50" \
        "-1_50_100" \
        "-1_140_200" \
        "-1_60_100" \
        "-1_20_50" \
        "-1_40_400" \
        "-1_40_200" \
        "-1_20_100" \
	"-1_30_100" 
}

partition_bonus()
{
    accept_taskset \
        "-1_600_1000" \
        "-1_1200_2000" \
        "-1_200_2000" \
        "-1_200_2000" \
        "-1_400_1000"
}

test_adm_bin_packing_bonus()
{
    echo PA > $PARTITION_POLICY_FILE
    partition_bonus
}

test_adm_bin_packing_baseline()
{
    echo WF > $PARTITION_POLICY_FILE
    partition_bonus
}

test_adm_single_cpu()
{
    do_test adm_single_cpu_accept_1
    do_test adm_single_cpu_accept_u_2
    do_test adm_single_cpu_reject_2
    do_test adm_single_cpu_accept_u_3
    do_test adm_single_cpu_accept_u_5
    do_test adm_single_cpu_accept_h_2
    do_test adm_single_cpu_accept_h_3
    do_test adm_single_cpu_accept_h_10
    do_test adm_single_cpu_accept_r_2
    do_test adm_single_cpu_accept_r_3
}

test_adm_multi_cpu()
{
    do_test adm_bin_packing_nfd_success_1
    do_test adm_bin_packing_nfd_fail_1
    do_test adm_bin_packing_bfd_success_1
    do_test adm_bin_packing_bfd_fail_1
    do_test adm_bin_packing_wfd_success_1
    do_test adm_bin_packing_wfd_fail_1
    do_test adm_bin_packing_ffd_success_1
    do_test adm_bin_packing_ffd_fail_1
}

test_help()
{
    echo "all"
    echo "enforce_2"
    #echo "enforce_no_signal"
    #echo "end_job"
    echo "easyperiodic_util_light"
    echo "easyperiodic_util_med"
    echo "easyperiodic_util_heavy"
    echo "reserve_status"
    echo
    echo "adm_single_cpu"
    echo
    echo "adm_single_cpu_accept_1"
    echo "adm_single_cpu_accept_u_2"
    echo "adm_single_cpu_reject_2"
    echo "adm_single_cpu_accept_u_3"
    echo "adm_single_cpu_accept_u_5"
    echo "adm_single_cpu_accept_h_2"
    echo "adm_single_cpu_accept_h_3"
    echo "adm_single_cpu_accept_h_10"
    echo "adm_single_cpu_accept_r_2"
    echo "adm_single_cpu_accept_r_3"
    echo
    echo "adm_multi_cpu"
    echo
    echo "adm_bin_packing_nfd_success_1"
    echo "adm_bin_packing_nfd_fail_1"
    echo "adm_bin_packing_bfd_success_1"
    echo "adm_bin_packing_bfd_fail_1"
    echo "adm_bin_packing_wfd_success_1"
    echo "adm_bin_packing_wfd_fail_1"
    echo "adm_bin_packing_ffd_success_1"
    echo "adm_bin_packing_ffd_fail_1"
}

if [ "$#" -lt 1 -o "$1" = "help" ]
then
    test_help
    exit 0
fi

# System setup
echo 0 > /sys/module/cpu_tegra3/parameters/auto_hotplug
for i in 0 1 2 3
do
    CPU_PATH=/sys/devices/system/cpu/cpu$i
    if [ "$(cat $CPU_PATH/online)" -ne 1 ]
    then
        echo 1 > $CPU_PATH/online
    fi
    sleep 0.5
    echo performance > $CPU_PATH/cpufreq/scaling_governor
done

TEST=$1
shift
test_$TEST $@
if [ "$?" -ne 0 ]
then
    echo "Test $TEST failed"
    exit 1
fi
echo "Test $TEST passed"
exit 0
