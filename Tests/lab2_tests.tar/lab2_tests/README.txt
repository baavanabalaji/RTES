18-648 Lab 2 Tests (2017)

Overview:

This package consists of the test script (lab2.sh), required TA binaries as well as TA source files for tests that need to be compiled against
user headers exported by you.


Files:

turn_on_only_one_cpu.sh
turn_on_all_cpus.sh

lab2.sh - Contains the following tests

periodic_cpu
Launches a periodic process and checks to makes sure that the utilization is within some threshold of expected.

periodic_affinity
Launches 4 periodic processes and puts them each on one core and then checks with top to ensure that those tasks were placed on the correct cores by the periodic app.

sufficient_budget
Runs ta periodic with C and T params, sets reserve with higher budget and makes sure SIGEXCESS is not received by periodic application.

insufficient_budget
Runs ta periodic with C and T params, sets reserve with lower budget and makes sure SIGEXCESS is received by periodic application.

reserve_affinity
Launches four periodic tasks and places them on different cores, and then set reservation on them and pin them all on one core randomly and checks if they are placed on the right core.

rms
Runs 4 ta periodics, sets reserves on them and then checks their priorities to make sure they are follow rms priority ordering based on their Ts.

one_reserve_file_kill
Runs ta periodic, sets a reserve on it, starts monitoring and checks if the sysfs util file for that thread exists. Then it kills that thread and makes sure the file does not exist anymore. 

one_reserve_file_cancel
Runs ta periodic, sets a reserve on it, starts monitoring and checks if the sysfs util file for that thread exists. Then it cancels the reservation on that thread and makes sure the file does not exist anymore. 

one_reserve_points_kill
Same as one_reserve_file_kill, except that it checks for the right number of entries in the sysfs util file, and checks the values logged against the parameters passed to periodic.

one_reserve_points_cancel
Same as one_reserve_file_cancel, except that it checks for the right number of entries in the sysfs util file, and checks the values logged against the parameters passed to periodic.

one_reserve_points_multiple
Same as one_reserve_points_kill, but reads multiple times from the sysfs util file after sleeping between cats to make sure values are being accumulated over time.

overutl
Runs two ta periodics, each of 0.8 utils, sets reserves on them on the same core of very high utilization, so that we can look at the sysfs util files to make sure the values are reasonable enough since they are on the same core

full_reserve
Runs ta periodic of 0.8 util, and sets 1.0 utilization reserve on that thread so that we can look at the sysfs util file to make sure the value is only around how much we expect it to be considering the actual utilization.

ui:
Runs a few tasks and sets reserve on a some of those tasks in order to test app. Leaves a few unreserved so that reservations can be set on them through the app.


Usage:

In order to run the tests on your applications and modules, place the
following user binaries & built modules in the same directory as lab2.sh.

PERIODIC_BINARY - periodic
RESERVE_BINARY - reserve

In order to run the TA binaries, leave them in the tools directory (created in the same directory as lab2.sh) as in this package. Build the periodic application using the Makefile in the tools directory, after pointing the EXP_HDRS variable to the correct location of your usr/include folder.
