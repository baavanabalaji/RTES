#!/sbin/bash
echo 0 > /sys/module/cpu_tegra3/parameters/auto_hotplug
echo "Auto hotplug: " `cat /sys/module/cpu_tegra3/parameters/auto_hotplug`
CPU_PATH=/sys/devices/system/cpu

echo 1 > $CPU_PATH/cpu0/online 2> /dev/null
for cpu in 1 2 3; do echo 0 > $CPU_PATH/cpu$cpu/online 2> /dev/null ; done
echo performance > $CPU_PATH/cpu0/cpufreq/scaling_governor

for cpu in 0 1 2 3; do echo "CPU"$cpu `cat $CPU_PATH/cpu$cpu/online`; done
for cpu in 0; do echo "CPU"$cpu `cat $CPU_PATH/cpu$cpu/cpufreq/scaling_governor`; done
