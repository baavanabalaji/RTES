#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <err.h>
#include <sys/time.h>
#include <signal.h>
#include <string.h>

//#define SIGXCESS 31
//#define SIGXCESS2 33

#define EXIT_BUDGET 2
#define EXIT_TERM 3

#define printf(...)

bool work = false;

void period_tick(int signal) {
    printf("period tick\n"); 
    if (work)
        printf("deadline missed\n");
    work = true;
}

void compute_over(int signal) {
    printf("compute over\n");
    work = false;
}

void budget_exceeded(int signal) {
    fprintf(stderr, "budget exceeded\n");
    work = false;
    exit(EXIT_BUDGET);
}

void terminated(int signal) {
    exit(EXIT_TERM);
}

void ms_to_timeval(struct timeval *tv, int ms) {
    tv->tv_sec = ms / 1000;
    tv->tv_usec = (ms % 1000) * 1000;
}

int main(int argc, char **argv)
{
    struct itimerval real_timer, virt_timer;
    struct timeval comp_time;
    struct sigaction period_sigact, compute_sigact, budget_sigact, term_sigact;
    int budget = -1;

    if (argc != 4 && argc != 5)
        errx(1, "Usage: %s <computation_ms> <period_ms> <core> [<budget>]\n", argv[0]);

    ms_to_timeval(&comp_time, atoi(argv[1]));
    virt_timer.it_interval.tv_sec = 0;
    virt_timer.it_interval.tv_usec = 0;

    ms_to_timeval(&real_timer.it_interval, atoi(argv[2]));
    real_timer.it_value = real_timer.it_interval;

    if (argc == 5)
        budget = atoi(argv[4]);
    
    memset(&period_sigact, 0, sizeof(period_sigact));
    period_sigact.sa_handler = period_tick;

    memset(&compute_sigact, 0, sizeof(compute_sigact));
    compute_sigact.sa_handler = compute_over;

    memset(&budget_sigact, 0, sizeof(budget_sigact));
    budget_sigact.sa_handler = budget_exceeded;

    memset(&term_sigact, 0, sizeof(term_sigact));
    term_sigact.sa_handler = terminated;

    if (sigaction(SIGALRM, &period_sigact, NULL))
        err(1, "failed to register period signal handler");
    if (sigaction(SIGVTALRM, &compute_sigact, NULL))
        err(1, "failed to register compute signal handler");
    if (budget==1) {
        if (signal(SIGEXCESS, budget_exceeded))
            err(1, "failed to register budget signal handler");
        //if (sigaction(SIGEXCESS2, &budget_sigact, NULL))
        //    err(1, "failed to register budget signal handler");
    }
    else if (budget>=32){ // students tend to do this 
        if (sigaction(budget, &budget_sigact, NULL))
            err(1, "failed to register budget signal handler");
    }
    if (sigaction(SIGTERM, &term_sigact, NULL))
        err(1, "failed to register term signal handler");

    if (setitimer(ITIMER_REAL, &real_timer, NULL))
        err(1, "failed to set period timer");

    while (1) {
        if (work) {
            virt_timer.it_value = comp_time;
            if (setitimer(ITIMER_VIRTUAL, &virt_timer, NULL))
                err(1, "failed to set compute timer");
        }
        while(work);
        pause();
    }

    return 0;
}
