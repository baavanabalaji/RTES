#!/sbin/bash
TOOLS_DIR=tools

TASKMON_PATH=/sys/rtes/taskmon

NUM_MANY=15
TOLERENCE=3

test_periodic_cpu(){

   ./periodic 400 1000 1 &
   PERIODIC_PID=$!
   UTL=$(top -n 2 -d 5 | grep $PERIODIC_PID | tail -1 | sed 's/<//g' | awk '{print $8}') 
   upper=$(awk 'BEGIN{ print ('$UTL' <= '40/4+$TOLERENCE') }')
   lower=$(awk 'BEGIN{ print ('$UTL' >= '40/4-$TOLERENCE') }')
   kill -9 $PERIODIC_PID
   wait $PERIODIC_PID
   if [ $upper -eq 1 ] && [ $lower -eq 1 ] 
   then   
	return 0
   fi
   echo "Get $UTL%, expect $((40/4))% (+-$TOLERENCE%)"

   return 1
}

test_periodic_affinity(){

   ./periodic 100 1000 0 &
   PIDS0=$!
   ./periodic 200 1000 1 &
   PIDS1=$!
   ./periodic 300 1000 2 &
   PIDS2=$!
   ./periodic 400 1000 3 &
   PIDS3=$!
   sleep 5
   SNAPSHOT=$(top -d 1 -n 3 | grep -E "$PIDS0|$PIDS1|$PIDS2|$PIDS3" | tail -4)
   for i in 0 1 2 3
   do
	eval "TPID=\${PIDS$i}"
	kill $TPID
	wait $TPID
   done
   for i in 0 1 2 3
   do
	eval "TPID=\${PIDS$i}"
   	RES=$(echo "$SNAPSHOT" | grep $TPID | sed 's/<//g' | awk '{print $7}')
	if [ $RES -ne $i ]
	then
		return 1
	fi
   done
   return 0
}

test_sufficient_budget()
{
    $TOOLS_DIR/periodic 100 500 0 1 &
    PERIODIC_PID=$!
    ./reserve set $PERIODIC_PID 200 500 0
    sleep 5
    kill $PERIODIC_PID
    wait $PERIODIC_PID
    if [ "$?" -eq 2 ] # 2 means exited by signal
    then
        return 1
    fi
    return 0
}

test_insufficient_budget()
{
    $TOOLS_DIR/periodic 400 500 0 1 &
    PERIODIC_PID=$!
    ./reserve set $PERIODIC_PID 500 1000 0
    sleep 5
    if ! ps | grep -q $PERIODIC_PID
    then
        # Cleanup after ourselfs in case of failed test
        kill $PERIODIC_PID
    fi
    wait $PERIODIC_PID
    if [ "$?" -ne 2 ] # 2 means exited by signal
    then
        return 1
    fi
    return 0
}

test_reserve_affinity(){
   ./periodic 50 500 0 &
   PIDS0=$!
   ./periodic 100 500 1 &
   PIDS1=$!
   ./periodic 125 500 2 &
   PIDS2=$!
   ./periodic 200 500 3 &
   PIDS3=$!
   sleep 1
   DEST=$((RANDOM%4))
   ./reserve set $PIDS0 500 1000 $DEST &
   ./reserve set $PIDS1 500 1000 $DEST &
   ./reserve set $PIDS2 500 1000 $DEST &
   ./reserve set $PIDS3 500 1000 $DEST &
   sleep 3
   SNAPSHOT=$(top -d 1 -n 3 | grep -E "$PIDS0|$PIDS1|$PIDS2|$PIDS3" | tail -4)
   for i in 0 1 2 3
   do
	eval "TPID=\${PIDS$i}"
	kill $TPID
	wait $TPID
   done
   for i in 0 1 2 3
   do
	eval "TPID=\${PIDS$i}"
   	RES=$(echo "$SNAPSHOT" | grep $TPID | sed 's/<//g' | awk '{print $7}')
	if [ $RES -ne $DEST ]
	then
		return 1
	fi
   done
   
   return 0

}

test_one_reserve_file_kill()
{
    chrt -f 50 $TOOLS_DIR/periodic 250 500 0 &
    PERIODIC_PID=$!
    sleep 1
    ./reserve set $PERIODIC_PID 999 1000 0
    sleep 1
    echo 1 > $TASKMON_PATH/enabled
    sleep 6
    echo 0 > $TASKMON_PATH/enabled
    sleep 2
    UTIL_FILE=$TASKMON_PATH/util/$PERIODIC_PID
    if ! [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file not found: '$UTIL_FILE'" 1>&2
        return 1
    fi
    kill $PERIODIC_PID
    sleep 1
    if [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file still exists: '$UTIL_FILE'" 1>&2
        return 1
    fi
    return 0
}

test_one_reserve_file_cancel()
{
    chrt -f 50 $TOOLS_DIR/periodic 250 500 0 &
    PERIODIC_PID=$!
    sleep 1
    ./reserve set $PERIODIC_PID 999 1000 0
    sleep 1
    echo 1 > $TASKMON_PATH/enabled
    sleep 6
    echo 0 > $TASKMON_PATH/enabled
    sleep 2
    UTIL_FILE=$TASKMON_PATH/util/$PERIODIC_PID
    if ! [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file not found: '$UTIL_FILE'" 1>&2
        return 1
    fi
    ./reserve cancel $PERIODIC_PID
    sleep 1
    if [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file still exists: '$UTIL_FILE'" 1>&2
        return 1
    fi
    kill $PERIODIC_PID
    return 0
}

check_util_data()
{
    local PERIODIC_PID=$1
    local NUM_LINES_REF=$2
    local UTIL_REF=$3

    local UTIL_FILE=$TASKMON_PATH/util/$PERIODIC_PID
    if ! [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file not found: '$UTIL_FILE'" 1>&2
        return 1
    fi

    mkdir -p tmp
    local UTIL_TMP_FILE=tmp/$$-util-$PERIODIC_PID
    cat $UTIL_FILE > $UTIL_TMP_FILE
    local NUM_LINES=$(wc -l $UTIL_TMP_FILE | cut -d' ' -f1)
    if [ "$NUM_LINES" -lt $NUM_LINES_REF ]
    then
        echo "FAILED: too few data points: $NUM_LINES" 1>&2
        return 1
    fi

    local LINE=0
    while read p
    do
        LINE=$((LINE+1))
        if [ "$LINE" -eq 1 ]
        then
            continue
        fi
        TOLERANCE=0.10
        UTIL="$(echo $p | cut -d' ' -f2)" 
        RESULT=$($TOOLS_DIR/fcalc $UTIL $UTIL_REF - 'a' $TOLERANCE '<')
        if [ "$RESULT" -ne 0 ]
        then
            echo "FAILED: utilization not within $TOLERANCE of $UTIL_REF: $UTIL" 1>&2
            return 1
        fi
    done < $UTIL_TMP_FILE
    rm $UTIL_TMP_FILE
    return 0
}


test_one_reserve_points_kill()
{
    local UTIL_REF=0.5 # change this if changing the following
    chrt -f 50 $TOOLS_DIR/periodic 250 500 0 &
    local PERIODIC_PID=$!
    sleep 1
    ./reserve set $PERIODIC_PID 999 1000 0
    echo 1 > $TASKMON_PATH/enabled
    sleep 6
    echo 0 > $TASKMON_PATH/enabled
    sleep 2
    NUM_LINES_REF=5
    if ! check_util_data $PERIODIC_PID $NUM_LINES_REF $UTIL_REF
    then
        return 1
    fi
    kill $PERIODIC_PID
    if [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file still exists: '$UTIL_FILE'" 1>&2
        return 1
    fi
    return 0
}

test_one_reserve_points_cancel()
{
    local UTIL_REF=0.5 # change this if changing the following
    chrt -f 50 $TOOLS_DIR/periodic 250 500 0 &
    local PERIODIC_PID=$!
    sleep 1
    ./reserve set $PERIODIC_PID 999 1000 0
    echo 1 > $TASKMON_PATH/enabled
    sleep 6
    echo 0 > $TASKMON_PATH/enabled
    sleep 2
    NUM_LINES_REF=5
    if ! check_util_data $PERIODIC_PID $NUM_LINES_REF $UTIL_REF
    then
        return 1
    fi
    ./reserve cancel $PERIODIC_PID
    sleep 1
    if [ -e "$UTIL_FILE" ]
    then
        echo "FAILED: util file still exists: '$UTIL_FILE'" 1>&2
        return 1
    fi
    kill $PERIODIC_PID
    return 0
}

test_one_reserve_points_multiple()
{
    local UTIL_REF=0.5 # change this if changing the following
    chrt -f 50 $TOOLS_DIR/periodic 250 500 0 &
    local PERIODIC_PID=$!
    sleep 1
    ./reserve set $PERIODIC_PID 999 1000 0
    echo 1 > $TASKMON_PATH/enabled
    NUM_LINES_REF=5
    for i in `seq 5`
    do
        sleep 6
        if ! check_util_data $PERIODIC_PID $NUM_LINES_REF $UTIL_REF
        then
            return 1
        fi
    done
    echo 0 > $TASKMON_PATH/enabled
    kill $PERIODIC_PID
    return 0
}

test_ui()
{
    chrt -f 50 $TOOLS_DIR/periodic 25 500 0 &
    PERIODIC_PID1=$!
    ./reserve set $PERIODIC_PID1 999 1000 0
    sleep 1
    chrt -f 50 $TOOLS_DIR/periodic 50 500 0 &
    PERIODIC_PID2=$!
    echo $PERIODIC_PID1 = 0.05
    echo $PERIODIC_PID2 = 0.1
    echo already_reserved $PERIODIC_PID1 $PERIODIC_PID2
    sleep 1
    ./reserve set $PERIODIC_PID2 999 1000 0
    sleep 1
    chrt -f 50 $TOOLS_DIR/periodic 75 500 0 &
    PERIODIC_PID3=$!
    sleep 1
    #./reserve set $PERIODIC_PID3 999 1000 0
    sleep 1
    chrt -f 50 $TOOLS_DIR/periodic 100 500 0 &
    PERIODIC_PID4=$!
    echo $PERIODIC_PID3 = 0.15
    echo $PERIODIC_PID4 = 0.2
    echo app_reserve $PERIODIC_PID3 $PERIODIC_PID4
    echo killall \"periodic\"
    return 0
}

test_overutl(){

    chrt -f 50 $TOOLS_DIR/periodic 400 500 2 &
    PERIODIC_PID1=$!
    ./reserve set $PERIODIC_PID1 999 1000 0
    chrt -f 50 $TOOLS_DIR/periodic 400 500 2 &
    PERIODIC_PID2=$!
    ./reserve set $PERIODIC_PID2 999 1000 0
    echo "Kill all tasks and check manually"
    return 0
}

test_full_reserve(){
    chrt -f 50 $TOOLS_DIR/periodic 400 500 0 &
    PERIODIC_PID1=$!
    ./reserve set $PERIODIC_PID1 1000 1000 0
    echo "Kill all tasks and check manually"
    echo kill $PERIODIC_PID1
    return 0
}

test_status(){

   echo "auto_hotplug:"
   cat /sys/module/cpu_tegra3/parameters/auto_hotplug
   echo "cpu status & governor:"
for i in 1 2 3
do
   CPU_PATH=/sys/devices/system/cpu/cpu$i
   cat $CPU_PATH/online
   cat $CPU_PATH/cpufreq/scaling_governor
done
}

test_rms(){
   $TOOLS_DIR/periodic 100 500 0 &
   PIDS0=$!
   $TOOLS_DIR/periodic 100 600 0 &
   PIDS1=$!
   $TOOLS_DIR/periodic 100 700 0 &
   PIDS2=$!
   $TOOLS_DIR/periodic 100 800 0 &
   PIDS3=$!
   ./reserve set $PIDS0 150 500 0 &
   ./reserve set $PIDS1 150 600 0 &
   ./reserve set $PIDS2 150 700 0 &
   ./reserve set $PIDS3 150 800 0 &
   sleep 3
   PRIO_0=$(cat /proc/$PIDS0/sched | grep "prio" | awk '{print $3}')
   PRIO_1=$(cat /proc/$PIDS1/sched | grep "prio" | awk '{print $3}')
   PRIO_2=$(cat /proc/$PIDS2/sched | grep "prio" | awk '{print $3}')
   PRIO_3=$(cat /proc/$PIDS3/sched | grep "prio" | awk '{print $3}')
   
   kill $PIDS0 $PIDS1 $PIDS2 $PIDS3

   if [ $PRIO_0 -le $PRIO_1 ] && [ $PRIO_1 -le $PRIO_2 ] && [ $PRIO_2 -le $PRIO_3 ]
   then
        return 0
   fi
   return 1
}


test_help()
{
    echo "all"
    echo "periodic_cpu"
    echo "periodic_affinity"
    echo "sufficient_budget"
    echo "insufficient_budget"
    echo "reserve_affinity"
    echo "rms"
    echo "one_reserve_file_kill"
    echo "one_reserve_file_cancel"
    echo "one_reserve_points_kill"
    echo "one_reserve_points_cancel"
    echo "one_reserve_points_multiple"
    echo "overutl -- Manually check in /sys/rtes/taskmon/util"
    echo "full_reserve -- Manually check in /sys/rtes/taskmon/util"
    echo "ui"
    echo "status (For checking)"
}

if [ "$1" = "help" ]
then
    test_help
    exit 0
fi

echo 0 > /sys/module/cpu_tegra3/parameters/auto_hotplug
for i in 1 2 3
do
    CPU_PATH=/sys/devices/system/cpu/cpu$i
    if [ "$(cat $CPU_PATH/online)" -ne 1 ]
    then
        echo 1 > $CPU_PATH/online
    fi
    sleep 0.5
    echo performance > $CPU_PATH/cpufreq/scaling_governor
done

TEST=$1
shift
test_$TEST $@
if [ "$?" -ne 0 ]
then
    echo "Test $TEST failed"
    exit 1
fi
echo "Test $TEST passed"
exit 0
